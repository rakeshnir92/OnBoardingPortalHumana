import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InitiateOnboardingComponent } from './Initiate-Onboarding/initiate-onboarding/initiate-onboarding.component';
import { ProjectsListComponent } from './projects-list/projects-list.component';
import { ProjectdetailComponent } from './projectdetail/projectdetail.component';

@NgModule({
  declarations: [
    AppComponent,
    InitiateOnboardingComponent,
    ProjectsListComponent,
    ProjectdetailComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
