import { Component, OnInit } from '@angular/core';
import { ProjectDetails } from '../models/project-details';
import { ProjectService } from '../services/project.service';
import { ActivatedRoute, Router } from '@angular/router';
import { projection } from '@angular/core/src/render3';
@Component({
  selector: 'app-projectdetail',
  templateUrl: './projectdetail.component.html',
  styleUrls: ['./projectdetail.component.css']
})
export class ProjectdetailComponent implements OnInit {

  private project:ProjectDetails;
  private isNew : boolean;



  constructor(private projserv:ProjectService,
    private routeData:ActivatedRoute,
    private router:Router) { }
    options:string[] ;
    optionSelected: any;

    onOptionsSelected1(event){
      this.project.Poc1 = event; //option value will be sent as event
     }
     onOptionsSelected2(event){
      this.project.Poc2 = event; //option value will be sent as event
     }
  ngOnInit() {
this.options=this.projserv.getOptions();
    this.routeData.params.subscribe(
      (params) =>{
        let projectName = params['name'];

        if(projectName==undefined){
          this.isNew=true;
          this.project=new ProjectDetails();          
        }else{
          this.project=this.projserv.get(projectName);
          this.isNew=false;          
        }
      }
    );

    
  }
  save(){
    if(this.isNew){
      this.projserv.add(this.project);
    }else{
      this.projserv.update(this.project);
    }
    this.router.navigateByUrl("/Projects");
  }
}
