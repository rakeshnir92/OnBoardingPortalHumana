import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InitiateOnboardingComponent } from './Initiate-Onboarding/initiate-onboarding/initiate-onboarding.component';
import { ProjectsListComponent } from './projects-list/projects-list.component';
import { ProjectdetailComponent } from './projectdetail/projectdetail.component';

const routes: Routes = [{path:'',component:InitiateOnboardingComponent},
{path:'Initiate',component:InitiateOnboardingComponent},
{path:'Projects',component:ProjectsListComponent},
{path:'edit/:name',component:ProjectdetailComponent},
{path:'add',component:ProjectdetailComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
