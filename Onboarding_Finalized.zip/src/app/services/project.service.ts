import { Injectable } from '@angular/core';
import { ProjectDetails } from '../models/project-details';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  projects:ProjectDetails[];
  options:string[];

  constructor() {

    this.projects=[
      {ProjectName:"HUMANA GB & TM",Poc1:"VinothKumar Kannan",Poc2:"Amirtharaj Jeyabalan"},
      {ProjectName:"HUMANA PROVIDER",Poc1:"Gayathri Rajendran",Poc2:"Abbas"},
      {ProjectName:"HUMANA HSD",Poc1:"Anirudh",Poc2:"Chandra"}  
      ];
      this.options=[
        "VinothKumar Kannan","Amirtharaj Jeyabalan","Gayathri Rajendran","Abbas","Chandra","Anirudh"
      ];
   }

   getAll():ProjectDetails[]{
    return this.projects;
  }
  getOptions():string[]{
    return this.options;
  }


  get(name:string){
    let index = this.projects.findIndex((project)=>(project.ProjectName==name));
    return index>-1?this.projects[index]:null;
  }

  add(project:ProjectDetails){
    this.projects.push(project);
  }

  update(project:ProjectDetails){
    let index= this.projects.findIndex((c)=>(c.ProjectName===project.ProjectName));
    if(index>-1){
      this.projects[index]=project;
    }
  }

  delete(name:string){
    let index= this.projects.findIndex((project)=>(project.ProjectName==name));
    if(index>-1){
      this.projects.splice(index,1);
    }
  }
}
