import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-initiate-onboarding',
  templateUrl: './initiate-onboarding.component.html',
  styleUrls: ['./initiate-onboarding.component.css']
})
export class InitiateOnboardingComponent implements OnInit {

  constructor(private routeData:ActivatedRoute,
    private router:Router) { }

    options:string[] = ["Humana GB & TM","Humana Providers" ,"Humana CGX"];
    optionSelected: any;

  ngOnInit() {
  }
  save(){
    if(confirm("OnBoarding is initiated for the selected Associate & Notification mails are triggered!!"))        
    this.router.navigateByUrl("")
  }
}
